./ds3_create_cust      1  10000 US   S 0 > us_cust.csv &
./ds3_create_cust  10001  20000 ROW  S 0 > row_cust.csv &
