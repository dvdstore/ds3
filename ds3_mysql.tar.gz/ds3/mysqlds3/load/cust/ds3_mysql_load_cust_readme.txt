ds3_mysql_load_cust_readme.txt

Instructions for loading DVD Store Version 3 (DS3) database customer data
(assumes data files are in directory ../../../data_files/cust)

  mysql --password=pw < mysqlds3_load_cust.sql

<davejaffe7@gmail.com> and <tmuirhead@vmware.com>  5/28/15
