ds3_mysql_load_membership_readme.txt

Instructions for loading DVD Store Version 3 (DS3) database membership data
(assumes data files are in directory ../../../data_files/membership)

  mysql --password=pw < mysqlds3_load_membership.sql

<davejaffe7@gmail.com> and <tmuirhead@vmware.com>  5/28/15
