ds3_mysql_web_readme.txt

The MySQL DVD Store currently has one web application interface -  PHP

For the ds3webdriver program and source, see ./ds3/drivers

Directories
-----------
./ds2/mysqlds2/web
./ds2/mysqlds2/web/php5        php5 pages 

<davejaffe7@gmail.com> and <tmuirhead@vmware.com>  7/15/15
