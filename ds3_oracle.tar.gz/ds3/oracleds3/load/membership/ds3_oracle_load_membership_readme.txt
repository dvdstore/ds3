ds3_oracle_load_membership_readme.txt

Instructions for loading DVD Store Version 3 (DS3) database customer
membership data
(assumes data files are in directory ./ds3/data_files/cust)

sh oracleds3_membership_sqlldr.sh

<davejaffe7@gmail.com> and <tmuirhead@vmware.com>  5/15/15
