sqlldr ds3/ds3 CONTROL=membership.ctl, LOG=membership.log, BAD=membership.bad, DATA=../../../data_files/membership/membership.csv
