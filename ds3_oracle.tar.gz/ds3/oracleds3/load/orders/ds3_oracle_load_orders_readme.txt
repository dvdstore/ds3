ds3_oracle_load_orders_readme.txt

Instructions for loading DVD Store Version 3 (DS3) database orders data
(assumes data files are in directory ./ds3/data_files/orders)

 sh oracleds3_orders_sqlldr.sh
 sh oracleds3_orderlines_sqlldr.sh
 sh oracleds3_cust_hist_sqlldr.sh

<davejaffe7@gmail.com> and <tmuirhead@vmware.com>  5/15/15
