ds3_oracle_load_prod_readme.txt

Instructions for loading DVD Store Version 3 (DS3) database product data
(assumes data files are in directory ./ds3/data_files/prod)

 sh oracleds3_prod_sqlldr.sh
 sh oracleds3_inv_sqlldr.sh

<davejaffe7@gmail.com> and <tmuirhead@vmware.com>  5/15/15
