sqlldr ds3/ds3 CONTROL=inv.ctl, LOG=inv.log, BAD=inv.bad, DATA=../../../data_files/prod/inv.csv 
