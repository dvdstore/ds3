sqlldr ds3/ds3 CONTROL=prod.ctl, LOG=prod.log, BAD=prod.bad, DATA=../../../data_files/prod/prod.csv 
