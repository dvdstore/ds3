ds3_oracle_load_reviews_readme.txt

Instructions for loading DVD Store Version 3 (DS3) database reviews data
(assumes data files are in directory ./ds3/data_files/reviews)

 sh oracleds3_reviews_sqlldr.sh
 sh oracleds3_reviewhelpfulness_sqlldr.sh

<davejaffe7@gmail.com> and <tmuirhead@vmware.com>  5/15/15
